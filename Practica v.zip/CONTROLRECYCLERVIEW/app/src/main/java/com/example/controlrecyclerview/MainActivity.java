package com.example.controlrecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView micontenedor;
    List<itemJuga> miarreglo;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        micontenedor = findViewById(R.id.Rvcontenedor);
        llenarRecyclerWiew();
    }

    @Override
    protected void onResume(){
        super.onResume();
        llenarRecyclerWiew();
    }

    public void llenarRecyclerWiew(){
        miarreglo = new ArrayList<>();
        miarreglo.add(
                new itemJuga(
                        "Leonel Messi",
                        "Delantero"
                ));
        miarreglo.add(
                new itemJuga(
                        "Damián Emiliano Martinez",
                        "Arquero"
                ));
        miarreglo.add(
                new itemJuga(
                        "Julián Álvarez",
                        "Delantero"
                ));
        miarreglo.add(
                new itemJuga(
                        "Ángel Di María",
                        "Centrocampista"
                ));
        miarreglo.add(
                new itemJuga(
                        "Paulo Dybala",
                        "Delantero"
                ));
        miarreglo.add(
                new itemJuga(
                        "Enze Fernández",
                        "Centrocampista"
                ));
        miarreglo.add(
                new itemJuga(
                        "Rodrigo De Paul",
                        "Centrocampista"
                ));
        miarreglo.add(
                new itemJuga(
                        "Lautaro Matínez",
                        "Delantero"
                ));
        miarreglo.add(
                new itemJuga(
                        "Alexis Mac Allister",
                        "Centrocampista"
                ));
        miarreglo.add(
                new itemJuga(
                        "Lisandro Martínez",
                        "Defensa"
                ));
        miarreglo.add(
                new itemJuga(
                        "Leandro Paredes",
                        "Centrocampista"
                ));
        miarreglo.add(
                new itemJuga(
                        "Marcos Acuña",
                        "Defensa"
                ));
        miarreglo.add(
                new itemJuga(
                        "Cristian Gabriel Romero",
                        "Defensa"
                ));
        miarreglo.add(
                new itemJuga(
                        "Nicolás Otamendi",
                        "Defensa"
                ));
        miarreglo.add(
                new itemJuga(
                        "Nahuel Molina",
                        "Defensa"
                ));
        miarreglo.add(
                new itemJuga(
                        "Gonsalo Montiel",
                        "Defensa"
                ));
        miarreglo.add(
                new itemJuga(
                        "Thiago Almada",
                        "Centrocampista"
                ));
        miarreglo.add(
                new itemJuga(
                        "Alejandro Darío Gómez",
                        "Centrocampista"
                ));
        miarreglo.add(
                new itemJuga(
                        "Nicolás Tagliafico",
                        "Defensa"
                ));
        miarreglo.add(
                new itemJuga(
                        "Juan Marcos Foyth",
                        "Defensa"
                ));
        miarreglo.add(
                new itemJuga(
                        "Ángel Correa",
                        "Delantero"
                ));
        miarreglo.add(
                new itemJuga(
                        "Exequiel Palacios",
                        "Centrocampista"
                ));
        miarreglo.add(
                new itemJuga(
                        "Franco Armani",
                        "Arquero"
                ));
        miarreglo.add(
                new itemJuga(
                        "Gerónimo Rulli",
                        "Arquero"
                ));
        miarreglo.add(
                new itemJuga(
                        "Guido Rodríguez",
                        "Centrocampista"
                ));

        // pasarlo a un adaptador

        AdaptadoritemJuga miAdaptador= new AdaptadoritemJuga(miarreglo,MainActivity.this);
        micontenedor.setHasFixedSize(true);
        micontenedor.setLayoutManager(new LinearLayoutManager(this));
        micontenedor.setAdapter(miAdaptador);

    }
}