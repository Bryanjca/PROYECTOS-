package com.example.controlrecyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadoritemJuga extends RecyclerView.Adapter<AdaptadoritemJuga.ViewHolder> {

    //declarar variables globales
    private List<itemJuga> miItem;
    private LayoutInflater miInflater;
    private Context miContexto;

    //contructor
    public AdaptadoritemJuga(List<itemJuga> miItem, Context miContexto) {
        this.miItem = miItem;
        this.miInflater = LayoutInflater.from(miContexto);
        this.miContexto = miContexto;
    }

    @NonNull
    @Override
    public AdaptadoritemJuga.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mivista = miInflater.inflate(R.layout.item_jugadores,null);
        return new AdaptadoritemJuga.ViewHolder(mivista);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadoritemJuga.ViewHolder holder, int position) {
        holder.bindData(miItem.get(position));

    }

    @Override
    public int getItemCount() {
        return miItem.size();
    }
    //crear clase
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView etiquetanombrejugador, etiquetajugador;
        Button botonvermas;
        ViewHolder(View itemvista){
            super(itemvista);
            etiquetanombrejugador = itemView.findViewById(R.id.nombrejugador);
            etiquetajugador = itemView.findViewById(R.id.jugador);
            botonvermas = itemvista.findViewById(R.id.btnverdetalles);
        }

        void bindData (final itemJuga Elitem){
            etiquetanombrejugador.setText(Elitem.getNombrejugador());
            etiquetajugador.setText(Elitem.getJugador());

            //asignar un evento
            botonvermas.setOnClickListener(new View.OnClickListener(){
                @Override
                public  void onClick(View v){
                    Toast.makeText(miContexto, "jugador: "+ Elitem.getNombrejugador(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(miContexto, "Rango: " +Elitem.getJugador(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
