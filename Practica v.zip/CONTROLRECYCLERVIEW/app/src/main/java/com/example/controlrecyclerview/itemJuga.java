package com.example.controlrecyclerview;

public class itemJuga {
    public String nombrejugador;
    public String jugador;

    public itemJuga(String nombrejugador, String jugador) {
        this.nombrejugador = nombrejugador;
        this.jugador = jugador;
    }

    public String getNombrejugador() {
        return nombrejugador;
    }

    public void setNombrejugador(String nombrejugador) {
        this.nombrejugador = nombrejugador;
    }

    public String getJugador() {
        return jugador;
    }

    public void setJugador(String jugador) {
        this.jugador = jugador;
    }
}
