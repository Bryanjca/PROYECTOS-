package com.example.convertidor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void Pesos(View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String pesosString = editText.getText().toString();
        double pesos = Double.parseDouble(pesosString);
        double dolares = pesos * 0.054;
        String dolaresString = String.format("%.2f", dolares);
        String mensaje = "Pesos: " + pesosString + " son Dolares: " + dolaresString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
    public void dolares(View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String dolaresString = editText.getText().toString();
        double dolares = Double.parseDouble(dolaresString);
        double pesos = dolares * 18.66;
        String pesosString = String.format("%.2f", pesos);
        String mensaje = "Dolares: " + dolaresString + " son Pesos: " + pesosString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }



    public void bitcoin(View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String bitcoinString = editText.getText().toString();
        double bitcoin = Double.parseDouble(bitcoinString);
        double dolares = bitcoin * 0.000046;
        String dolaresString = String.format("%.6f", dolares);
        String mensaje = "Dolares: " + bitcoinString + " son Bitcoin: " + dolaresString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
    public void bitcoindolar(View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String dolaresString = editText.getText().toString();
        double dolares = Double.parseDouble(dolaresString);
        double bitcoin = dolares * 21688.50;
        String bitcoinString = String.format("%.2f", bitcoin);
        String mensaje = "Bitcoin: " + bitcoinString + " son Dolares: " + dolaresString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }



    public void bitcoinlempira(View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String bitcoinString = editText.getText().toString();
        double bitcoin = Double.parseDouble(bitcoinString);
        double lempira = bitcoin * 0.0000019;
        String lempiraString = String.format("%.6f", lempira);
        String mensaje = "Lempira: " + bitcoinString + " son Bitcoin: " + lempiraString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
    public void bitcoinlem (View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String lempiraString = editText.getText().toString();
        double lempira = Double.parseDouble(lempiraString);
        double bitcoin = lempira * 537105.48;
        String bitcoinString = String.format("%.2f", bitcoin);
        String mensaje = "Lempira: " + lempiraString + " son Bitcoin: " + bitcoinString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }



    public void bitque (View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String bitcoinString = editText.getText().toString();
        double bitcoin = Double.parseDouble(bitcoinString);
        double quetzales = bitcoin * 0.0000059;
        String quetzalesString = String.format("%.5f", quetzales);
        String mensaje = "Quetzales: " + bitcoinString + " son Bitcoin: " + quetzalesString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
    public void quebit (View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String quetzalesString = editText.getText().toString();
        double quetzales = Double.parseDouble(quetzalesString);
        double bitcoin = quetzales * 170931.48;
        String bitcoinString = String.format("%.2f", bitcoin);
        String mensaje = "Quetzales: " + quetzalesString + " son Bitcoin: " + bitcoinString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }



    public void corbit (View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String bitcoinString = editText.getText().toString();
        double bitcoin = Double.parseDouble(bitcoinString);
        double cordobas = bitcoin * 0.0000013;
        String cordobasString = String.format("%.6f", cordobas);
        String mensaje = "Cordobas: " + bitcoinString + " son Bitcoin: " + cordobasString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
    public void cor (View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String cordobasString = editText.getText().toString();
        double cordobas = Double.parseDouble(cordobasString);
        double bitcoin = cordobas * 795679.82;
        String bitcoinString = String.format("%.2f", bitcoin);
        String mensaje = "Córdobas: " + cordobasString + " son Bitcoin: " + bitcoinString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }



    public void colo (View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String bitcoinString = editText.getText().toString();
        double bitcoin = Double.parseDouble(bitcoinString);
        double colones = bitcoin * 7.9e-8;
        String colonesString = String.format("%.6f", colones);
        String mensaje = "Colones: " + bitcoinString + " son Bitcoin: " + colonesString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
    public void colbit (View view) {
        EditText editText = findViewById(R.id.editTextNumber);
        String colonesString = editText.getText().toString();
        double colones = Double.parseDouble(colonesString);
        double bitcoin = colones * 12631161.82;
        String bitcoinString = String.format("%.2f", bitcoin);
        String mensaje = "Colones: " + colonesString + " son Bitcoin: " + bitcoinString;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}