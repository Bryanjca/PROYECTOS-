from django.shortcuts import render
from django.urls import path
from app_registro import views
from.models import Area,Clientes,LosEmpleados,Ventas


def lista_are(request):
    Are = Area.objects.all()
    return render (request,"area.html",{"area":Are})

""""
def lista_Clie(request):
    frutas = fruta.objects.all()
    return render (request,"listadofrut.html",{"listaprov":frutas})

# Create your views here.
"""
