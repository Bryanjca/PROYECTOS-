from django.contrib import admin
from.import models

admin.site.register(models.Clientes)
admin.site.register(models.Ventas)
admin.site.register(models.Area)
admin.site.register(models.LosEmpleados)

# Register your models here.
