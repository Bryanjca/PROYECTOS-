package net.lrivas.tabble;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import net.lrivas.tabble.frament.Fragment_1;
import net.lrivas.tabble.frament.Fragment_2;
import net.lrivas.tabble.frament.Fragment_3;

public class MyViewPagerAdapter extends FragmentStateAdapter {
    public MyViewPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position){
        switch (position){
            case 0:
                return new Fragment();
            case 1:
                return new Fragment_1();
            case 2:
                return new Fragment_2();
            case 3:
                return new Fragment_3();
            default:
                return new Fragment();
        }
    }
    @Override
    public int getItemCount(){
        return 3;
    }
}
