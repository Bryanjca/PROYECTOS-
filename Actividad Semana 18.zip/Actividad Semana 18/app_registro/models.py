from django.db import models

class Clientes(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    edad = models.IntegerField()
    dui = models.IntegerField()

    def __str__(self):
        return f"Nombre: {self.nombre} Apellido: {self.apellido} Edad: {self.edad} Dui: {self.dui}"

class Area(models.Model):
    id = models.AutoField(primary_key=True)
    nombre_del_area = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=255)

    def __str__(self):
        return f"Nombre del area: {self.nombre_del_area} Descrpcion: {self.descripcion}"

class LosEmpleados(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    edad = models.IntegerField()
    area = models.ForeignKey(Area, on_delete=models.CASCADE)

    def __str__(self):
        return f"Nombre: {self.nombre} Apellido: {self.apellido} Edad: {self.edad} area: {self.area}"
    

class Ventas(models.Model):
    id = models.AutoField(primary_key=True)
    fecha_venta = models.DateTimeField()
    monto = models.FloatField()
    cliente = models.ForeignKey(Clientes, on_delete=models.CASCADE)
    empleado = models.ForeignKey(LosEmpleados,on_delete=models.CASCADE)

    def __str__(self):
        return f"Fecha de venta: {self.fecha_venta} Monto: {self.monto} Cliente: {self.cliente} Empleado: {self.empleado}"
    
