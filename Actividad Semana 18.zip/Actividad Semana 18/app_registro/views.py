from django.shortcuts import render
from django.urls import path
from app_registro import views
from.models import Area,Clientes,LosEmpleados,Ventas


def lista_are(request):
    Are = Area.objects.all()
    return render (request,"area.html",{"area":Are})

def lista_cli(request):
    Cli = Clientes.objects.all()
    return render (request,"cliente.html",{"cliente":Cli})

def lista_emp(request):
    Emp = LosEmpleados.objects.all()
    return render (request,"empleados.html",{"empleados":Emp})
    
def lista_ven(request):
    Ven = Ventas.objects.all()
    return render (request,"venta.html",{"venta":Ven})
    

""""
def lista_Clie(request):
    frutas = fruta.objects.all()
    return render (request,"listadofrut.html",{"listaprov":frutas})

# Create your views here.
"""
