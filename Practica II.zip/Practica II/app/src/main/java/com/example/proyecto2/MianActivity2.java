package com.example.proyecto2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.text.BreakIterator;

public class MianActivity2 extends AppCompatActivity{
    //objetos
    TextView Etiquetanombre, Etiquetamonto, Etiquetaservicio, Etiquetasueldo;
    Button btnregresar;
    private BreakIterator txtnombre;
    private  BreakIterator txtmonto;
    private  BreakIterator txtservicio;
    private  BreakIterator txtsueldo;

    @SuppressLint("MissingInFlatedId")
    @Override
    protected  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Etiquetanombre = findViewById(R.id.txtnombre);
        Etiquetamonto = findViewById(R.id.txtmonto);
        Etiquetasueldo = findViewById(R.id.txtNumber);
        Etiquetaservicio = findViewById(R.id.txtservicio);
        btnregresar = findViewById(R.id.btnregresar);

        btnregresar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                regresar();
            }

            private void regresar() {
               Intent ventana = new Intent(MianActivity2.this, MainActivity.class);
               startActivity(ventana);
            }
        });
    }
    @Override
    protected void onResume(){
        super.onResume();
        //datos

        Bundle datos = getIntent().getExtras();
        if (datos!=null){
            String nombre = datos.getString("nombre");
            String servicio = datos.getString("servicio");
            int monto = datos.getInt("monto");

            txtnombre.setText("nombre:"+nombre);
            txtmonto.setText("monto:"+monto);
            txtservicio.setText("servicio:"+servicio);

            double isr = 0.10;
            txtmonto.setText("monto+"+"$"+(monto*isr));
            txtsueldo.equals("sueldo neto:"+"$"+(monto*(monto*isr)));
            txtnombre.setText("isr"+"10%");
        }
    }

}