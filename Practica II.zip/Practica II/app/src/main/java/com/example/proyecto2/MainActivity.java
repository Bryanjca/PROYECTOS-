package com.example.proyecto2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    // Objetos
    Button botoncito;
    EditText cajita, cajamonto, cajaservicio, cajasueldo;

    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Referencia
        botoncito = findViewById(R.id.btnCalcular);
        cajita = findViewById(R.id.txtnombre);
        cajamonto = findViewById(R.id.txtmonto);
        cajaservicio = findViewById(R.id.txtservicio);
        cajasueldo = findViewById(R.id.Etiquetasueldo);

        //asignar
        botoncito.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                salude();
            }
            private  void  salude(){
                String nombre;
                int monto;
                String servicio;
                nombre = cajita.getText().toString();
                monto = Integer.parseInt(cajamonto.getText().toString());
                servicio = cajaservicio.getText().toString();
                Intent ventana = new Intent(MainActivity.this,MianActivity2.class);
                setContentView(R.layout.activity_main2);
                ventana.putExtra("nombre", nombre);
                ventana.putExtra("monton", monto);
                ventana.putExtra("servicio", servicio);
                //Toast.makeText(MainActivity.this, "hola"+nombre+ ",tu monto es: " + monto+ ",tu servicio fue: "+ servicio, Toast.LENGTH_SHORT).show();
            }
        });
    }
}