package net.lrivas.libreriaaudio;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import net.lrivas.libreriaaudio.R;

public class MainActivity extends AppCompatActivity {

    private ImageView fondo;                      //calse de imageview
    private Button uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve, diez, once, doce, trece, catorce, quince;           //botones
    MediaPlayer sonido1, sonido2, sonido3, sonido4, sonido5, sonido6, sonido7, sonido8, sonido9, sonido10, sonido11, sonido12, sonido13, sonido14, sonido15;   //sonidos

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fondo = (ImageView) findViewById(R.id.fondo);
        uno = (Button) findViewById(R.id.uno);
        dos = (Button) findViewById(R.id.dos);
        tres = (Button) findViewById(R.id.tres);
        cuatro = (Button) findViewById(R.id.cuatro);
        cinco = (Button) findViewById(R.id.cinco);
        seis = (Button) findViewById(R.id.seis);
        siete = (Button) findViewById(R.id.siete);
        ocho = (Button) findViewById(R.id.ocho);
        nueve = (Button) findViewById(R.id.nueve);
        diez = (Button) findViewById(R.id.diez);
        once = (Button) findViewById(R.id.once);
        doce = (Button) findViewById(R.id.doce);
        trece = (Button) findViewById(R.id.trece);
        catorce = (Button) findViewById(R.id.catorce);
        quince = (Button) findViewById(R.id.quince);

        sonido1 = MediaPlayer.create(this, R.raw.uno);
        sonido2 = MediaPlayer.create(this, R.raw.dos);
        sonido3 = MediaPlayer.create(this, R.raw.tres);
        sonido4 = MediaPlayer.create(this, R.raw.cuatro);
        sonido5 = MediaPlayer.create(this, R.raw.cinco);
        sonido6 = MediaPlayer.create(this, R.raw.audio_seis);
        sonido7 = MediaPlayer.create(this, R.raw.siete);
        sonido8 = MediaPlayer.create(this, R.raw.ocho);
        sonido9 = MediaPlayer.create(this, R.raw.nueve);
        sonido10 = MediaPlayer.create(this, R.raw.diez);
        sonido11 = MediaPlayer.create(this, R.raw.once);
        sonido12 = MediaPlayer.create(this, R.raw.doce);
        sonido13 = MediaPlayer.create(this, R.raw.trece);
        sonido14 = MediaPlayer.create(this, R.raw.catorce);
        sonido15 = MediaPlayer.create(this, R.raw.quince);


        uno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sonido1.start();
                fondo.setImageResource(R.drawable.i_uno);
            }
        });
        dos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sonido2.start();
                fondo.setImageResource(R.drawable.i_dos);
            }
        });
        tres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sonido3.start();
                fondo.setImageResource(R.drawable.i_tres);
            }
        });
            cuatro.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido4.start();
                    fondo.setImageResource(R.drawable.i_cuatro);
                }
            });
            cinco.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido5.start();
                    fondo.setImageResource(R.drawable.i_cinco);
                }
            });
            seis.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido6.start();
                    fondo.setImageResource(R.drawable.i_seis);
                }
            });
            siete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido7.start();
                    fondo.setImageResource(R.drawable.i_siete);
                }
            });
            ocho.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido8.start();
                    fondo.setImageResource(R.drawable.i_ocho);
                }
            });
            nueve.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido9.start();
                    fondo.setImageResource(R.drawable.i_nueve);
                }
            });
            diez.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido10.start();
                    fondo.setImageResource(R.drawable.i_diez);
                }
            });
            once.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido11.start();
                    fondo.setImageResource(R.drawable.i_once);
                }
            });
            doce.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido12.start();
                    fondo.setImageResource(R.drawable.i_doce);
                }
            });
            trece.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido13.start();
                    fondo.setImageResource(R.drawable.i_trece);
                }
            });
            catorce.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido14.start();
                    fondo.setImageResource(R.drawable.i_catorce);
                }
            });
            quince.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sonido15.start();
                    fondo.setImageResource(R.drawable.i_quince);
                }
            });
        }
        public void click(View view) {
            fondo.setImageResource(R.drawable.i_uno);
            fondo.setImageResource(R.drawable.i_dos);
            fondo.setImageResource(R.drawable.i_tres);
            fondo.setImageResource(R.drawable.i_cuatro);
            fondo.setImageResource(R.drawable.i_cinco);
            fondo.setImageResource(R.drawable.i_seis);
            fondo.setImageResource(R.drawable.i_siete);
            fondo.setImageResource(R.drawable.i_ocho);
            fondo.setImageResource(R.drawable.i_nueve);
            fondo.setImageResource(R.drawable.i_diez);
            fondo.setImageResource(R.drawable.i_once);
            fondo.setImageResource(R.drawable.i_doce);
            fondo.setImageResource(R.drawable.i_trece);
            fondo.setImageResource(R.drawable.i_catorce);
            fondo.setImageResource(R.drawable.i_quince);

        }
    }