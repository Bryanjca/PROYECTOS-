package com.example.cuotauniversitaria;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
        EditText cuota1;
        //EditText cum;
        Spinner spin1, spin2, spincum;

        TextView ptotal, etiqueta1, etiqueta2,etiqueta3,etiqueta4;
    private Bundle savedInstanceState;

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            cuota1=findViewById(R.id.cuota);
            spincum = findViewById(R.id.cum1);
            spin1=findViewById(R.id.spe1);
            spin2=findViewById(R.id.spe2);
            ptotal=findViewById(R.id.total);
            etiqueta1=findViewById(R.id.lb);
            etiqueta2=findViewById(R.id.CostoC);
            etiqueta3=findViewById(R.id.descuP);
            etiqueta4=findViewById(R.id.dcum);
        }

        public void pagou(View View){
            try {

                String selec, selec2, selec3;
                double cuota3;
                double por = 0;
                int notacum;
                double n1 = 0;

                cuota3 = Double.parseDouble(cuota1.getText().toString());
                selec = spin1.getSelectedItem().toString();
                selec2 = spin2.getSelectedItem().toString();
                selec3 = spincum.getSelectedItem().toString();

                if (selec.equals("Ingeniería en Manejo y Gestión de Base de datos")) {
                    por = (cuota3 * 1.30 + 20);
                    etiqueta1.setText("Aumento de costos por carrera: $ " + (cuota3 * 1.30 - cuota3));
                    etiqueta2.setText("Costos de Laboratorios: $" + 20);

                }
                if (selec.equals("Ingeniería en Sistemas")) {

                    por = (cuota3 * 1.40 + 25);
                    etiqueta1.setText("Aumento de costos por carrera: $ " + (cuota3 * 1.40 - cuota3));
                    etiqueta2.setText("Costos de Laboratorios: $ " + 25);

                }
                if (selec.equals("Técnico en Sistemas")) {
                    por = (cuota3 * 1.45) + 30;
                    etiqueta1.setText("Aumento de costos por carrera: $ " + (cuota3 * 1.45 - cuota3));
                    etiqueta2.setText("Costos de Laboratorios: $" + 30);

                }
                if (selec3.equals("10")) {

                    n1 = (por - (por * 0.25));
                    etiqueta3.setText("Descuento por su institucion: $ " + (por * 0.25));

                }

                if (selec3.equals("9")) {
                    n1 = (por - (por * 0.25));
                    etiqueta3.setText("Descuento por Cum: $ " + (por * 0.25));

                }

                if (selec3.equals("8")) {
                    n1 = (por - (por * 0.20));
                    etiqueta3.setText("Descuento por Cum: $ " + (por * 0.20));
                }


                if (selec3.equals("7")) {
                    n1 = (por - (por * 0.15));
                    etiqueta3.setText("Descuento por Cum: $ " + (por * 0.15));
                }


                if (selec2.equals("Institucion Publica")) {
                    ptotal.setText("Su total a pagar es: $ " + (n1 - (n1 * 0.05)));
                    etiqueta4.setText("Descuento de Institucion: $ " + (n1 * 0.05));


                }
                else{
                    if (selec2.equals("Institucion Privada")) {
                        ptotal.setText("Su total a pagar es: $ " + (n1 - (n1 * 0.10)));
                        etiqueta4.setText("Descuento de Institucion: $ " + (n1 * 0.10));

                    }
                }
            }catch (Exception error){

                Log.e("errorMainActivity",error.getMessage());
            }

        }
    }